"""StudyPal: the study tracker as a regular desktop app."""

__version__ = "1.0.5"  # major.minor.patch: the patch goes up by one with every commit
